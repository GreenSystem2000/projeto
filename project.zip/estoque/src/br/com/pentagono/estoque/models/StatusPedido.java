package br.com.pentagono.estoque.models;

public enum StatusPedido {
	EM_ABERTO, RECEBIDO, CANCELADO;
}
