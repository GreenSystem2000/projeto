package br.com.pentagono.estoque.controllers;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import br.com.pentagono.estoque.daos.MovimentoEstoqueDAO;
import br.com.pentagono.estoque.models.MovimentoEstoque;



@Controller
@Transactional
@RequestMapping("/movimento")

public class MovimentoEstoqueController {
	@Autowired
	private MovimentoEstoqueDAO movimentoestoqueDAO;
	
	@RequestMapping(method = RequestMethod.GET, name = "listarmovimentoUrl")
	public ModelAndView listar() {

		ModelAndView mav = new ModelAndView("movimento/lista");
		List<MovimentoEstoque> dados = movimentoestoqueDAO.listarTodos();
		mav.addObject("listarmovimento", dados);

		return mav;
	}

	@RequestMapping(value = "/{id}", name = "detalharMovimentorUrl")
	public ModelAndView detalhar(@PathVariable Long id) {

		MovimentoEstoque movimentoVindoDoBanco = movimentoestoqueDAO.buscarPorId(id);
		ModelAndView mav = new ModelAndView("movimento/detalhe");
		mav.addObject("movimento", movimentoVindoDoBanco);
		return mav;
	}
	
	
}