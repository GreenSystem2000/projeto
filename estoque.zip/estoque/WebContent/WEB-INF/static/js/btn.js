$(document).ready(function(){
	$('.btn1').hover(function(){
		$(this).css({
			'background-color' : 'green',
			'border-color' : '#005500'
		});
		$('#img1').css({
			'filter' : 'contrast(100) sepia(100%) brightness(2.0)'
		});
	});
			
	$('.btn1').mouseout(function(){
		$(this).css({
			'background-color' : 'white',
			'border-color' : 'green'
		})
		$('#img1').css({
			'filter' : ''
		});
	});
			
	$('#img1').hover(function(){
		$(this).css({   
			'filter' : 'contrast(100) sepia(100%) brightness(2.0)'
		});
		$('.btn1').css({
			'background-color' : 'green',
			'border-color' : '#005500'
		});
	});
			
			
	$('.btn2').hover(function(){
		$(this).css({
			'background-color' : 'green',
			'border-color' : '#005500'
		});
		$('#img2').css({
			'filter' : 'contrast(100) sepia(100%) brightness(2.0)'
		});
	});
			
	$('.btn2').mouseout(function(){
		$(this).css({
			'background-color' : 'white',
			'border-color' : 'green'
		})
		$('#img2').css({
			'filter' : ''
		});
	});
			
	$('#img2').hover(function(){
		$(this).css({   
			'filter' : 'contrast(100) sepia(100%) brightness(2.0)'
		});
		$('.btn2').css({
			'background-color' : 'green',
			'border-color' : '#005500'
		});
	});
			
			
	$('.btn3').hover(function(){
		$(this).css({
			'background-color' : 'green',
			'border-color' : '#005500'
		});
		$('#img3').css({
			'filter' : 'contrast(100) sepia(100%) brightness(2.0)'
		});
	});
			
	$('.btn3').mouseout(function(){
		$(this).css({
			'background-color' : 'white',
			'border-color' : 'green'
		})
		$('#img3').css({
			'filter' : ''
		});
	});
			
	$('#img3').hover(function(){
		$(this).css({   
			'filter' : 'contrast(100) sepia(100%) brightness(2.0)'
		});
		$('.btn3').css({
			'background-color' : 'green',
			'border-color' : '#005500'
		});
	});
			
			
	$('.btn4').hover(function(){
		$(this).css({
			'background-color' : 'green',
			'border-color' : '#005500'
		});
		$('#img4').css({
			'filter' : 'contrast(100) sepia(100%) brightness(2.0)'
		});
	});
			
	$('.btn4').mouseout(function(){
		$(this).css({
			'background-color' : 'white',
			'border-color' : 'green'
		})
		$('#img4').css({
			'filter' : ''
		});
	});
			
	$('#img4').hover(function(){
		$(this).css({   
			'filter' : 'contrast(100) sepia(100%) brightness(2.0)'
		});
		$('.btn4').css({
			'background-color' : 'green',
			'border-color' : '#005500'
		});
	});
});