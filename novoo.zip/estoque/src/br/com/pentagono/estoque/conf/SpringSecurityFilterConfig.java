package br.com.pentagono.estoque.conf;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class SpringSecurityFilterConfig extends AbstractSecurityWebApplicationInitializer {

}
