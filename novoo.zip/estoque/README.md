# estoque
Projeto estoque utilizado na disciplina: Linguagem de programação II, da faculdade Pentagono

Este projeto será incrementado ao longo das aulas.
